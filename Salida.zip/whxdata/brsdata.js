(function() {
var data = {};
window.rh.model.publish(rh.consts('KEY_BRS_DATA'), data, { sync:true });
})();