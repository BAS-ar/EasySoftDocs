(function() {
var index =  {"type":"index","chunkinfos":[{"type":"chunkinfo","first":"Alta modificación y eliminación de datos","last":"Vistas","num":"19","node":"idata1"}]};
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), index, { sync:true });
})();
